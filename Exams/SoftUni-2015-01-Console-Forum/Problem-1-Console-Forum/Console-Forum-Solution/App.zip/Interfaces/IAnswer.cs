﻿namespace ConsoleForum.Interfaces
{
    public interface IAnswer : IPost
    {
    }
}
