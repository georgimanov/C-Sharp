﻿namespace ConsoleForum.Contracts
{
    public interface IExecutable
    {
        void Execute();
    }
}
