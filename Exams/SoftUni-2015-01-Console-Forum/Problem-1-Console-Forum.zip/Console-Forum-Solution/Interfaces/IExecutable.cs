﻿using System;

namespace ConsoleForum.Interfaces
{
    public interface IExecutable
    {
        void Execute();
    }
}
